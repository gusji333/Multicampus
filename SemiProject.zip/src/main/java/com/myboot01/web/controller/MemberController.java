package com.myboot01.web.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.myboot01.web.service.MemberService;
import com.myboot01.web.vo.MemberVO;



@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	
	
	
	@RequestMapping(value = "memberInsert", 
			method= {RequestMethod.POST},
			produces = "application/text; charset=utf8")
	@ResponseBody
	public String memberInsert(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("memberInsert() 호출됨");
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		String name=request.getParameter("name");
		
		
		try {
			MemberVO memberVO=new MemberVO(id, pw, name);
			memberService.insertMember(memberVO);
			System.out.println(memberVO);
			return name+"님 회원가입 되셨습니다";
		} catch (DataAccessException e) {
			return "회원가입에 실패하셨습니다";
		}
		
		//return "회원 가입 ok";
	}
	
	
	@RequestMapping(value="loginById",
			method= {RequestMethod.POST},
			produces = "application/text; charset=utf8")
	@ResponseBody
	public String loginById(HttpServletRequest request, HttpServletResponse response) {
		
		String id=request.getParameter("id");
		String pw=request.getParameter("pw");
		JSONObject json=new JSONObject();
		try {
			MemberVO memberVO=new MemberVO(id, pw, null);
			memberVO=memberService.loginById(memberVO);
			System.out.println(memberVO);
			if(memberVO.getName()!=null) {
				HttpSession session=request.getSession();
				session.setAttribute("member", memberVO);
				json.put("name", memberVO.getName());
			}else {
				return "로그인 실패";
			}

			
		} catch (DataAccessException e) {
			e.printStackTrace();
			return "로그인 실패";
		}
		return json.toJSONString();
		
	}
	
	@RequestMapping(value = "logout", 
			method= {RequestMethod.POST},
			produces = "application/text; charset=utf8")			
	@ResponseBody
	public String logout(HttpServletRequest request,
			HttpServletResponse response){
		
			HttpSession session=request.getSession(false);
			session.invalidate();
			return "";
		
	}

	
	
	@ResponseBody
	@RequestMapping("/deleteMember")
	public String deleteMember(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id=request.getParameter("id");
			memberService.deleteMember(id);
			return "회원 삭제 완료";
		} catch (DataAccessException e) {
			e.printStackTrace();
			return "회원 삭제 실패";
		}
	}
	
	
	@ResponseBody
	@RequestMapping("/updateMember")
	public String updateMember(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id=request.getParameter("id");
			String pw=request.getParameter("pw");
			String name=request.getParameter("name");
			String address=request.getParameter("address");
			MemberVO memberVO=new MemberVO(id, pw, name, address, 0);
			memberService.updateMember(memberVO);
			return "회원 정보 수정 완료";
		} catch (DataAccessException e) {
			e.printStackTrace();
			return "회원 정보 수정 실패";
		}
	}
	
	
	
	@RequestMapping("/selectAllMemberList")
	public String selectAllMemberList(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<MemberVO> list=memberService.selectAllMemberList();
			return "ok.jsp";
		} catch (DataAccessException e) {
			e.printStackTrace();
			return "fail.jsp";
		}
	}
	
	
	
}//end class
