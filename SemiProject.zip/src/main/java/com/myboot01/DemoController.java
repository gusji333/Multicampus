package com.myboot01;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {
	@RequestMapping("/")
	public String home() {
		System.out.println("home() 호출됨");
		return "index.html";
	}
	
	@RequestMapping("/hello.do")
	public String hello() {
		System.out.println("hello() 호출됨");
		return "html/hello.html";
	}
}
