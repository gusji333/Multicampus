$(document).ready(function(){
	$("#memberInsertBtn").click(function(){//회원 가입 처리
	
		var name=$("#name").val();
		var id=$("#id").val();
		var pw=$("#pw").val();
		
		//alert(name+":"+id+":"+pw);
		
		$.post("../memberInsert",
			  {
			    name:name,
			    id:id,
			    pw:pw
			  },
			  function(data, status){
			    alert( data);
			   	window.close();
			  });
		
	});

});


$(document).ready(function(){
	$("#loginBtn").click(function(){
		const id=$("#id").val();
		const pw=$("#pw").val();
		//alert(id+":"+pw);
		$.post(
			"loginById",
			{id,pw},
			function(data){
				var obj=JSON.parse(data);
				if(obj.name){
					data = obj.name+"님 환영합니다\t"+
					"<input type='button' value='logout' id='logoutBtn' class='btn btn-primary'>";
					$.cookie("logined",data);
					$("#loginSpan").html(data);
				}else{
					alert("다시 로그인 해주세요");
					location.reload();
				}
			}//end function
		);//end post
	});//end
});


$(document).on("click", "#logoutBtn", function(event) { //로그아웃 처리
	
		$.post("logout",
			  {			   
			   
			  },
			  function(data, status){		  	
			  	
			  	$.removeCookie("logined");	    
				location.reload();						   
			  }
		);//end post() 
});//end 로그아웃 처리
	
	

	
